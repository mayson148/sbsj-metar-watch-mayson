package br.com.sbsj.metar

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class Metar(
    val raw: String,
    val obsTime: String,     // ex.: "1500Z"
    val category: String,    // VFR / MVFR / IFR / LIFR
    val wind: String,        // ex.: "090/08kt"
    val visibility: String,  // ex.: "9999" (vazio em CAVOK)
    val sky: String,         // ex.: "FEW030" ou "CAVOK"
    val temp: String,        // ex.: "28/19"
    val qnh: String          // ex.: "Q1014"
) {
    /** Linha principal da complication longa. */
    val line1: String
        get() = listOf(wind, visibility, sky).filter { it.isNotEmpty() }.joinToString(" ")

    /** Linha secundária (título) da complication longa. */
    val line2: String
        get() = "${MetarRepository.STATION} $obsTime $temp°C $qnh"
}

object MetarRepository {
    const val STATION = "SBSJ"
    private const val ENDPOINT = "https://aviationweather.gov/api/data/metar?ids=$STATION&format=raw"

    private const val PREFS = "metar_prefs"
    private const val KEY_RAW = "raw"
    private const val KEY_LAST_OK = "last_ok"
    private const val KEY_LAST_TRY = "last_try"
    private const val KEY_ENABLED = "enabled"

    /** Sem busca bem-sucedida há mais que isso = dado considerado velho. */
    const val STALE_AFTER_MS = 5 * 60_000L

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- estado ----------

    fun isEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ENABLED, true)

    fun setEnabled(ctx: Context, value: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun cached(ctx: Context): Metar? =
        prefs(ctx).getString(KEY_RAW, null)?.let { parse(it) }

    fun lastOk(ctx: Context): Long = prefs(ctx).getLong(KEY_LAST_OK, 0L)

    fun lastTry(ctx: Context): Long = prefs(ctx).getLong(KEY_LAST_TRY, 0L)

    fun isStale(ctx: Context): Boolean =
        System.currentTimeMillis() - lastOk(ctx) > STALE_AFTER_MS

    // ---------- rede ----------

    /** Busca o METAR. Retorna true se o texto mudou em relação ao último salvo. */
    suspend fun refresh(ctx: Context): Boolean {
        val p = prefs(ctx)
        val now = System.currentTimeMillis()
        val raw = download()
        val editor = p.edit().putLong(KEY_LAST_TRY, now)
        var changed = false
        if (raw != null) {
            changed = raw != p.getString(KEY_RAW, null)
            editor.putString(KEY_RAW, raw).putLong(KEY_LAST_OK, now)
        }
        editor.apply()
        return changed
    }

    private suspend fun download(): String? = withContext(Dispatchers.IO) {
        val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", "sbsj-wear-metar/1.0")
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                null
            } else {
                conn.inputStream.bufferedReader().use { it.readText() }
                    .lineSequence()
                    .map { it.trim() }
                    .firstOrNull { it.isNotEmpty() }
                    ?.takeIf { STATION in it }
            }
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    // ---------- parser ----------

    private val timeRe = Regex("^\\d{6}Z$")
    private val windRe = Regex("^(VRB|\\d{3})(\\d{2,3})(?:G(\\d{2,3}))?KT$")
    private val skyRe = Regex("^(FEW|SCT|BKN|OVC|VV)(\\d{3})")
    private val tempRe = Regex("^(M?\\d{2})/(M?\\d{2})$")
    private val qnhRe = Regex("^Q(\\d{4})$")

    private fun fmtTemp(s: String): String =
        if (s.startsWith("M")) "-" + s.substring(1).toInt() else s.toInt().toString()

    fun parse(raw: String): Metar {
        val tokens = raw.trim().split(Regex("\\s+"))

        var obs = "--"
        var wind = "--"
        var visM: Int? = null
        var sky: String? = null
        var ceilingFt: Int? = null
        var temp = "--"
        var qnh = "----"
        var cavok = false

        for (t in tokens) {
            if (t == "RMK" || t == "TEMPO" || t == "BECMG" || t == "NOSIG") break

            if (timeRe.matches(t)) {
                obs = t.substring(2, 6) + "Z"
                continue
            }

            val w = windRe.matchEntire(t)
            if (w != null) {
                val gust = w.groupValues[3]
                wind = w.groupValues[1] + "/" + w.groupValues[2] +
                    (if (gust.isNotEmpty()) "G$gust" else "") + "kt"
                continue
            }

            if (t == "CAVOK") {
                cavok = true
                sky = "CAVOK"
                continue
            }

            if (visM == null && t.length == 4 && t.all { it.isDigit() }) {
                visM = t.toInt()
                continue
            }

            val s = skyRe.find(t)
            if (s != null) {
                if (sky == null) sky = t.take(6)
                val type = s.groupValues[1]
                if (type == "BKN" || type == "OVC" || type == "VV") {
                    val h = s.groupValues[2].toInt() * 100
                    val c = ceilingFt
                    if (c == null || h < c) ceilingFt = h
                }
                continue
            }

            if (t == "NSC" || t == "SKC" || t == "NCD" || t == "CLR") {
                if (sky == null) sky = t
                continue
            }

            val tm = tempRe.matchEntire(t)
            if (tm != null) {
                temp = fmtTemp(tm.groupValues[1]) + "/" + fmtTemp(tm.groupValues[2])
                continue
            }

            val q = qnhRe.matchEntire(t)
            if (q != null) {
                qnh = "Q" + q.groupValues[1]
                continue
            }
        }

        // Categoria de voo (critério FAA: teto e visibilidade)
        val v = if (cavok) 9999 else (visM ?: 9999)
        val vSm = v / 1609.34
        val c = ceilingFt ?: Int.MAX_VALUE
        val category = when {
            obs == "--" -> "N/D"
            c < 500 || vSm < 1.0 -> "LIFR"
            c < 1000 || vSm < 3.0 -> "IFR"
            c <= 3000 || vSm <= 5.0 -> "MVFR"
            else -> "VFR"
        }

        return Metar(
            raw = raw.trim(),
            obsTime = obs,
            category = category,
            wind = wind,
            visibility = if (cavok) "" else (visM?.toString() ?: ""),
            sky = sky ?: "",
            temp = temp,
            qnh = qnh
        )
    }
}
