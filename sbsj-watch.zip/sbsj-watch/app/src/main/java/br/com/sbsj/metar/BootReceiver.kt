package br.com.sbsj.metar

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Religa o loop de atualização depois que o relógio reinicia. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && MetarRepository.isEnabled(context)) {
            try {
                MetarUpdateService.start(context)
            } catch (e: Exception) {
                // Em versões novas do Android o sistema pode barrar o início no boot.
                // Nesse caso basta abrir o app uma vez.
            }
        }
    }
}
