package br.com.sbsj.metar

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.runBlocking
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Segunda página do app: mostra o TAF de SBSJ. Deslize para a direita para voltar. */
class TafActivity : Activity() {

    private lateinit var tafView: TextView
    private lateinit var statusView: TextView
    private lateinit var refreshBtn: Button

    private val handler = Handler(Looper.getMainLooper())
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    @Volatile
    private var loading = false

    // Quanto tempo o TAF guardado vale antes de buscar de novo ao abrir a tela
    private val maxAgeMs = 10 * 60_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        render()
        val age = System.currentTimeMillis() - MetarRepository.lastTafOk(this)
        if (MetarRepository.cachedTaf(this) == null || age > maxAgeMs) load()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val pad = dp(26)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, dp(40), pad, dp(40))
        }

        fun label(size: Float, color: Int): TextView {
            val v = TextView(this)
            v.textSize = size
            v.setTextColor(color)
            v.gravity = Gravity.CENTER
            return v
        }

        val title = label(14f, Color.LTGRAY)
        title.text = "TAF ${MetarRepository.STATION}"
        tafView = label(12f, Color.WHITE)
        tafView.gravity = Gravity.START
        tafView.setPadding(0, dp(8), 0, dp(8))
        statusView = label(11f, Color.GRAY)
        refreshBtn = Button(this)
        refreshBtn.text = "Atualizar"
        refreshBtn.setOnClickListener { load() }

        val lp = { LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ) }
        col.addView(title, lp())
        col.addView(tafView, lp())
        col.addView(statusView, lp())
        col.addView(refreshBtn, lp())

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(col)
        setContentView(scroll)
    }

    /** Busca o TAF fora da thread principal e redesenha a tela. */
    private fun load() {
        if (loading) return
        loading = true
        statusView.text = "Buscando…"
        refreshBtn.isEnabled = false
        Thread {
            try {
                runBlocking { MetarRepository.refreshTaf(applicationContext) }
            } catch (e: Exception) {
                // mostra o que estiver guardado
            }
            handler.post {
                loading = false
                if (!isFinishing && !isDestroyed) {
                    refreshBtn.isEnabled = true
                    render()
                }
            }
        }.start()
    }

    private fun render() {
        val taf = MetarRepository.cachedTaf(this)
        val lastOk = MetarRepository.lastTafOk(this)

        tafView.text = if (taf == null) "Sem TAF no momento" else MetarRepository.formatTaf(taf)

        if (!loading) {
            val old = System.currentTimeMillis() - lastOk > maxAgeMs
            statusView.text = when {
                lastOk == 0L -> "Sem conexão ou sem dados"
                old -> "Buscado às ${clock.format(Date(lastOk))}\nSem conexão, mostrando dado antigo"
                else -> "Buscado às ${clock.format(Date(lastOk))}"
            }
        }
    }
}
