package br.com.sbsj.metar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Serviço em primeiro plano que busca o METAR a cada [INTERVAL_MS]
 * e avisa a complication quando há algo novo para mostrar.
 */
class MetarUpdateService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "METAR SBSJ",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NOTIF_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        if (loop?.isActive != true) {
            loop = scope.launch {
                var lastStale: Boolean? = null
                while (isActive) {
                    try {
                        val changed = MetarRepository.refresh(applicationContext)
                        val stale = MetarRepository.isStale(applicationContext)
                        // Só empurra para o relógio quando algo mudou (poupa bateria)
                        if (changed || stale != lastStale) requestComplicationUpdate()
                        lastStale = stale
                        getSystemService(NotificationManager::class.java)
                            .notify(NOTIF_ID, buildNotification())
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // tenta de novo no próximo ciclo
                    }
                    delay(INTERVAL_MS)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** Avisa a complication e o tile de que há dado novo. */
    private fun requestComplicationUpdate() {
        ComplicationDataSourceUpdateRequester
            .create(this, ComponentName(this, MetarComplicationService::class.java))
            .requestUpdateAll()
        try {
            androidx.wear.tiles.TileService.getUpdater(this)
                .requestUpdate(MetarTileService::class.java)
        } catch (e: Exception) {
            // tile não adicionado ou indisponível: sem problema
        }
    }

    private fun buildNotification(): Notification {
        val metar = MetarRepository.cached(this)
        val text = when {
            metar == null -> "Aguardando dados…"
            MetarRepository.isStale(this) -> "Sem atualização · último ${metar.obsTime}"
            else -> metar.raw
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_plane)
            .setContentTitle("METAR ${MetarRepository.STATION}")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "metar"
        private const val NOTIF_ID = 1

        /** Intervalo entre buscas. 60 s = a cada minuto. */
        const val INTERVAL_MS = 60_000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, MetarUpdateService::class.java)
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MetarUpdateService::class.java))
        }
    }
}
