# METAR SBSJ para Galaxy Watch 6 (Wear OS)

App + complication que busca o METAR de SBSJ (São José dos Campos) a cada 60 segundos
em `aviationweather.gov` (gratuito, sem chave de API) e mostra no mostrador.

## O que aparece

- **Complication curta:** categoria de voo (`VFR`, `MVFR`, `IFR`, `LIFR`) com o título `SBSJ`.
- **Complication longa:** `090/08kt 9999 FEW030` e, no título, `SBSJ 1500Z 28/19°C Q1014`.
- **Dado velho:** se ficar mais de 5 minutos sem buscar com sucesso, a complication mostra `--` / "Sem atualização" em vez de exibir um METAR antigo como se fosse atual.
- **Tocar na complication** abre o app, que mostra o METAR completo (cru) e a hora da última busca.

## Como compilar

1. Instale o **Android Studio** (com JDK 17) e abra a pasta `sbsj-watch`.
2. Aguarde o *Gradle sync*. Se ele sugerir atualizar o Android Gradle Plugin, aceite.
3. Conecte o relógio (veja abaixo) e clique em **Run ▶** com o módulo `app`.

## Como instalar no Galaxy Watch 6

1. No relógio: **Configurações → Sobre o relógio → Versão do software** → toque 5 vezes em "Versão do software" para liberar o modo desenvolvedor.
2. **Configurações → Opções do desenvolvedor →** ative **Depuração ADB** e **Depurar via Wi-Fi**.
3. No computador (mesma rede Wi-Fi): `adb pair IP:PORTA_PAREAMENTO` (código mostrado no relógio) e depois `adb connect IP:PORTA`.
4. Rode o app pelo Android Studio, ou instale o APK: `adb install app-debug.apk`.

## Como colocar no mostrador

1. Abra o app **METAR SBSJ** uma vez (aceite a permissão de notificações). Isso inicia o serviço que busca o METAR.
2. No mostrador: segure o dedo → **Personalizar → Complicações** → escolha o espaço → **METAR SBSJ**.
   (O mostrador precisa aceitar complicações de terceiros; os mostradores padrão da Samsung aceitam.)

## Observações

- **Bateria:** buscar a cada minuto gasta bem mais bateria que o normal. Para mudar, edite `INTERVAL_MS` em `MetarUpdateService.kt`. O app só empurra dados para o mostrador quando o METAR muda, para reduzir o gasto.
- **METAR muda pouco:** SBSJ normalmente publica de hora em hora (mais SPECI quando o tempo muda). Buscar a cada minuto serve para pegar o novo assim que sair.
- **Serviço precisa estar rodando:** o app mantém uma notificação fixa (serviço em primeiro plano). Se o sistema matar o serviço ou você tocar em "Pausar", a complication para de atualizar (e fica `--` depois de 5 min). Se o relógio estiver parado/carregando por muito tempo, o Android pode atrasar as buscas.
- **Relógio sem LTE:** usa a internet do celular pareado (Bluetooth) ou Wi-Fi.
- **Aviso:** a categoria de voo é calculada de forma simples (teto/visibilidade). Informativo apenas, não use para decisão operacional de voo.
- **Não compilado aqui:** o código foi escrito sem acesso ao Android SDK; se o Gradle reclamar de alguma versão, ajuste em `build.gradle.kts`.
