package br.com.sbsj.metar

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.LongTextComplicationData
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService

/**
 * Complication "METAR SBSJ".
 *  - Curta: categoria de voo (VFR/MVFR/IFR/LIFR) com título SBSJ
 *  - Longa: vento, visibilidade e nuvens; título com hora, temp/orvalho e QNH
 * Se a última busca bem-sucedida for antiga, mostra o último METAR com "?" (curta)
 * ou com o atraso em minutos (longa).
 * Os dados vêm do cache preenchido pelo [MetarUpdateService].
 */
class MetarComplicationService : SuspendingComplicationDataSourceService() {

    override fun getPreviewData(type: ComplicationType): ComplicationData? = when (type) {
        ComplicationType.SHORT_TEXT -> shortText("VFR", MetarRepository.STATION, "SBSJ VFR")
        ComplicationType.LONG_TEXT -> longText(
            "090/08kt 9999 FEW030",
            "SBSJ 1500Z 28/19°C Q1014",
            "SBSJ METAR"
        )
        else -> null
    }

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        var metar = MetarRepository.cached(this)
        if (metar == null) {
            // Primeira vez (ou cache vazio): tenta buscar na hora
            MetarRepository.refresh(this)
            metar = MetarRepository.cached(this)
        }
        val stale = MetarRepository.isStale(this)
        val age = MetarRepository.ageMinutes(this)

        return when (request.complicationType) {
            ComplicationType.SHORT_TEXT -> when {
                metar == null -> shortText("--", MetarRepository.STATION, "SBSJ sem dados")
                stale -> shortText(
                    "${metar.category}?",
                    MetarRepository.STATION,
                    "SBSJ ${metar.category}, sem atualização há $age minutos. ${metar.raw}"
                )
                else -> shortText(
                    metar.category,
                    MetarRepository.STATION,
                    "SBSJ ${metar.category}. ${metar.raw}"
                )
            }

            ComplicationType.LONG_TEXT -> when {
                metar == null -> longText("Sem dados", MetarRepository.STATION, "SBSJ sem dados")
                stale -> longText(
                    metar.line1,
                    "${MetarRepository.STATION} ${metar.obsTime} · atraso ${age}min",
                    "SBSJ sem atualização há $age minutos. ${metar.raw}"
                )
                else -> longText(metar.line1, metar.line2, metar.raw)
            }

            else -> null
        }
    }

    private fun tapIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun shortText(text: String, title: String, description: String) =
        ShortTextComplicationData.Builder(
            text = PlainComplicationText.Builder(text).build(),
            contentDescription = PlainComplicationText.Builder(description).build()
        )
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(tapIntent())
            .build()

    private fun longText(text: String, title: String, description: String) =
        LongTextComplicationData.Builder(
            text = PlainComplicationText.Builder(text).build(),
            contentDescription = PlainComplicationText.Builder(description).build()
        )
            .setTitle(PlainComplicationText.Builder(title).build())
            .setTapAction(tapIntent())
            .build()
}
