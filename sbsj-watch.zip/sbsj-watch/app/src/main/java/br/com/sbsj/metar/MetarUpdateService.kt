package br.com.sbsj.metar

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Serviço em primeiro plano que busca o METAR a cada [INTERVAL_MS].
 *
 * O ritmo vem de um alarme do sistema (AlarmManager), que acorda o relógio mesmo com a tela
 * apagada. Um timer comum para de contar quando o processador dorme. Além disso, quando a
 * rede volta, busca na hora.
 */
class MetarUpdateService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private var lastStale: Boolean? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID,
            "METAR SBSJ",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        registerNetworkCallback()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NOTIF_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        if (!MetarRepository.isEnabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Agenda o próximo alarme antes de tudo, assim a cadência não se perde se algo falhar
        scheduleNext()
        scope.launch { tick() }
        return START_STICKY
    }

    override fun onDestroy() {
        cancelAlarm()
        networkCallback?.let {
            try {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
            } catch (e: Exception) {
                // já removido
            }
        }
        scope.cancel()
        super.onDestroy()
    }

    // ---------- busca ----------

    private suspend fun tick() {
        mutex.withLock {
            // Mantém o processador acordado só durante a busca
            val wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "metar:tick")
            wl.acquire(30_000L)
            try {
                val changed = MetarRepository.refresh(applicationContext)
                val stale = MetarRepository.isStale(applicationContext)
                // Só empurra para o relógio quando algo mudou (poupa bateria)
                if (changed || stale != lastStale) requestComplicationUpdate()
                lastStale = stale
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIF_ID, buildNotification())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // tenta de novo no próximo alarme
            } finally {
                if (wl.isHeld) wl.release()
            }
        }
    }

    private fun registerNetworkCallback() {
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Rede voltou: busca na hora em vez de esperar o próximo alarme
                scope.launch { tick() }
            }
        }
        try {
            getSystemService(ConnectivityManager::class.java).registerDefaultNetworkCallback(cb)
            networkCallback = cb
        } catch (e: Exception) {
            // sem callback, o alarme continua cobrindo
        }
    }

    // ---------- alarme ----------

    private fun alarmIntent(): PendingIntent = PendingIntent.getForegroundService(
        this,
        1,
        Intent(this, MetarUpdateService::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun scheduleNext() {
        val am = getSystemService(AlarmManager::class.java)
        val at = SystemClock.elapsedRealtime() + INTERVAL_MS
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, alarmIntent())
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, alarmIntent())
        }
    }

    private fun cancelAlarm() {
        getSystemService(AlarmManager::class.java).cancel(alarmIntent())
    }

    // ---------- complication / tile / notificação ----------

    /** Avisa a complication e o tile de que há dado novo. */
    private fun requestComplicationUpdate() {
        ComplicationDataSourceUpdateRequester
            .create(this, ComponentName(this, MetarComplicationService::class.java))
            .requestUpdateAll()
        try {
            androidx.wear.tiles.TileService.getUpdater(this)
                .requestUpdate(MetarTileService::class.java)
        } catch (e: Exception) {
            // tile não adicionado ou indisponível: sem problema
        }
    }

    private fun buildNotification(): Notification {
        val metar = MetarRepository.cached(this)
        val text = when {
            metar == null -> "Aguardando dados…"
            MetarRepository.isStale(this) -> "Sem atualização · último ${metar.obsTime}"
            else -> metar.raw
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_plane)
            .setContentTitle("METAR ${MetarRepository.STATION}")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "metar"
        private const val NOTIF_ID = 1

        /** Intervalo entre buscas. 60 s = a cada minuto. */
        const val INTERVAL_MS = 60_000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, MetarUpdateService::class.java)
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MetarUpdateService::class.java))
        }
    }
}
