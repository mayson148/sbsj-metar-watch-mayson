package br.com.sbsj.metar

import android.graphics.Color
import androidx.concurrent.futures.CallbackToFutureAdapter
import androidx.wear.tiles.ActionBuilders
import androidx.wear.tiles.ColorBuilders
import androidx.wear.tiles.DimensionBuilders
import androidx.wear.tiles.LayoutElementBuilders
import androidx.wear.tiles.ModifiersBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import androidx.wear.tiles.TimelineBuilders
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.runBlocking

/**
 * Tile "METAR SBSJ": categoria de voo grande e colorida, com vento, visibilidade,
 * nuvens, temperatura/orvalho, QNH e hora da observação.
 * Os dados vêm do cache preenchido pelo [MetarUpdateService].
 */
class MetarTileService : TileService() {

    override fun onTileRequest(
        requestParams: RequestBuilders.TileRequest
    ): ListenableFuture<TileBuilders.Tile> =
        CallbackToFutureAdapter.getFuture<TileBuilders.Tile> { completer ->
            if (MetarRepository.cached(applicationContext) != null) {
                completer.set(buildTile())
            } else {
                // Primeira vez: tenta buscar na hora, fora da thread principal
                Thread {
                    try {
                        runBlocking { MetarRepository.refresh(applicationContext) }
                    } catch (e: Exception) {
                        // segue mostrando "aguardando dados"
                    }
                    completer.set(buildTile())
                }.start()
            }
            "metar-tile"
        }

    override fun onTileResourcesRequest(
        requestParams: RequestBuilders.ResourcesRequest
    ): ListenableFuture<ResourceBuilders.Resources> =
        CallbackToFutureAdapter.getFuture<ResourceBuilders.Resources> { completer ->
            completer.set(ResourceBuilders.Resources.Builder().setVersion(RES_VERSION).build())
            "metar-tile-resources"
        }

    private fun buildTile(): TileBuilders.Tile {
        val metar = MetarRepository.cached(this)
        val stale = MetarRepository.isStale(this)

        val column = LayoutElementBuilders.Column.Builder()
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .addContent(text("METAR ${MetarRepository.STATION}", 12f, Color.LTGRAY))

        when {
            metar == null -> {
                column.addContent(text("--", 36f, Color.GRAY))
                column.addContent(spacer())
                column.addContent(text("Aguardando dados", 14f, Color.WHITE))
                column.addContent(text("Abra o app", 12f, Color.LTGRAY))
            }

            stale -> {
                column.addContent(text("--", 36f, Color.GRAY))
                column.addContent(spacer())
                column.addContent(text("Sem atualização", 14f, Color.WHITE))
                column.addContent(text("último ${metar.obsTime}", 12f, Color.LTGRAY))
            }

            else -> {
                column.addContent(text(metar.category, 36f, colorFor(metar.category)))
                column.addContent(spacer())
                column.addContent(text(metar.line1, 14f, Color.WHITE))
                column.addContent(text("${metar.temp}°C  ${metar.qnh}", 14f, Color.WHITE))
                column.addContent(text("obs ${metar.obsTime}", 12f, Color.LTGRAY))
            }
        }

        val root = LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(openAppModifiers())
            .addContent(column.build())
            .build()

        return TileBuilders.Tile.Builder()
            .setResourcesVersion(RES_VERSION)
            .setFreshnessIntervalMillis(60_000L)
            .setTimeline(TimelineBuilders.Timeline.fromLayoutElement(root))
            .build()
    }

    private fun text(value: String, sizeSp: Float, color: Int): LayoutElementBuilders.Text =
        LayoutElementBuilders.Text.Builder()
            .setText(value)
            .setMaxLines(2)
            .setFontStyle(
                LayoutElementBuilders.FontStyle.Builder()
                    .setSize(DimensionBuilders.sp(sizeSp))
                    .setColor(ColorBuilders.argb(color))
                    .build()
            )
            .build()

    private fun spacer(): LayoutElementBuilders.Spacer =
        LayoutElementBuilders.Spacer.Builder()
            .setHeight(DimensionBuilders.dp(4f))
            .build()

    /** Tocar no tile abre o app. */
    private fun openAppModifiers(): ModifiersBuilders.Modifiers {
        val launch = ActionBuilders.LaunchAction.Builder()
            .setAndroidActivity(
                ActionBuilders.AndroidActivity.Builder()
                    .setPackageName(packageName)
                    .setClassName(MainActivity::class.java.name)
                    .build()
            )
            .build()
        val clickable = ModifiersBuilders.Clickable.Builder()
            .setId("open_app")
            .setOnClick(launch)
            .build()
        return ModifiersBuilders.Modifiers.Builder()
            .setClickable(clickable)
            .build()
    }

    private fun colorFor(category: String): Int = when (category) {
        "VFR" -> Color.rgb(76, 175, 80)
        "MVFR" -> Color.rgb(66, 165, 245)
        "IFR" -> Color.rgb(239, 83, 80)
        "LIFR" -> Color.rgb(224, 64, 251)
        else -> Color.GRAY
    }

    companion object {
        private const val RES_VERSION = "1"
    }
}
