package br.com.sbsj.metar

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var catView: TextView
    private lateinit var rawView: TextView
    private lateinit var statusView: TextView
    private lateinit var toggle: Button

    private val handler = Handler(Looper.getMainLooper())
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val ticker = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        buildUi()

        if (MetarRepository.isEnabled(this)) MetarUpdateService.start(this)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val pad = dp(26)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, dp(40), pad, dp(40))
        }

        fun label(size: Float, color: Int): TextView {
            val v = TextView(this)
            v.textSize = size
            v.setTextColor(color)
            v.gravity = Gravity.CENTER
            return v
        }

        val title = label(14f, Color.LTGRAY)
        title.text = "METAR ${MetarRepository.STATION}"
        catView = label(30f, Color.WHITE)
        rawView = label(12f, Color.WHITE)
        statusView = label(11f, Color.GRAY)
        toggle = Button(this)
        toggle.setOnClickListener { onToggle() }

        val lp = { LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ) }
        col.addView(title, lp())
        col.addView(catView, lp())
        col.addView(rawView, lp())
        col.addView(statusView, lp())
        col.addView(toggle, lp())

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(col)
        setContentView(scroll)
    }

    private fun onToggle() {
        val enable = !MetarRepository.isEnabled(this)
        MetarRepository.setEnabled(this, enable)
        if (enable) MetarUpdateService.start(this) else MetarUpdateService.stop(this)
        render()
    }

    private fun colorFor(category: String): Int = when (category) {
        "VFR" -> Color.rgb(76, 175, 80)
        "MVFR" -> Color.rgb(66, 165, 245)
        "IFR" -> Color.rgb(239, 83, 80)
        "LIFR" -> Color.rgb(224, 64, 251)
        else -> Color.GRAY
    }

    private fun render() {
        val metar = MetarRepository.cached(this)
        val enabled = MetarRepository.isEnabled(this)
        val stale = MetarRepository.isStale(this)
        val lastOk = MetarRepository.lastOk(this)

        if (metar == null) {
            catView.text = "--"
            catView.setTextColor(Color.GRAY)
            rawView.text = "Aguardando dados…"
        } else {
            catView.text = metar.category
            catView.setTextColor(colorFor(metar.category))
            rawView.text = metar.raw
        }

        statusView.text = buildString {
            append(if (enabled) "Atualizando a cada 60 s" else "Atualização pausada")
            if (lastOk > 0) append("\nÚltima busca ok: ${clock.format(Date(lastOk))}")
            if (enabled && stale) append("\nSem conexão ou sem dados")
        }
        toggle.text = if (enabled) "Pausar" else "Iniciar"
    }
}
